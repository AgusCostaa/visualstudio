﻿Partial Class MusicaDBDataSet
    Partial Class UsuarioDataTable

        Private Sub UsuarioDataTable_UsuarioRowChanging(sender As Object, e As UsuarioRowChangeEvent) Handles Me.UsuarioRowChanging

        End Sub

        Private Sub UsuarioDataTable_ColumnChanging(sender As Object, e As DataColumnChangeEventArgs) Handles Me.ColumnChanging
            If (e.Column.ColumnName = Me.ClaveColumn.ColumnName) Then
                'Agregar código de usuario aquí
            End If

        End Sub

    End Class

End Class

Namespace MusicaDBDataSetTableAdapters
    
    Partial Class UsuarioTableAdapter

    End Class

    Partial Public Class UsuarioTableAdapter
    End Class
End Namespace
