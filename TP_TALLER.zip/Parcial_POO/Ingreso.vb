﻿Imports System.Security.Cryptography
Imports System.Text
Public Class Ingreso

    Private Sub UsuarioBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.UsuarioBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.MusicaDBDataSet)

    End Sub


    Private Sub UsuarioBindingNavigatorSaveItem_Click_1(sender As Object, e As EventArgs) Handles UsuarioBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.UsuarioBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.MusicaDBDataSet)

    End Sub

    Private Sub Ingreso_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'MusicaDBDataSet.Usuario' Puede moverla o quitarla según sea necesario.
        Me.UsuarioTableAdapter.Fill(Me.MusicaDBDataSet.Usuario)

    End Sub
    Private intentosFallidos As Integer = 0
    Private Sub Btningre_Click(sender As Object, e As EventArgs) Handles Btningre.Click
        Dim claveCifrada As String = GenerarHash(ClaveTextBox.Text)
        Dim filas As Integer

        ' Intento 1: Buscar usando la clave cifrada (como pide la pizarra)
        filas = Me.UsuarioTableAdapter.FillBy(Me.MusicaDBDataSet.Usuario, UsuarioTextBox.Text, claveCifrada)

        ' Intento 2: Si no encuentra, busca con la clave común (por si VS pisó la BD)
        If filas = 0 Then
            filas = Me.UsuarioTableAdapter.FillBy(Me.MusicaDBDataSet.Usuario, UsuarioTextBox.Text, ClaveTextBox.Text)
        End If

        If filas > 0 Then
            usuario = UsuarioTextBox.Text
            permiso = PermisoTextBox.Text
            intentosFallidos = 0
            Me.Hide()
            Form1.Show()
        Else
            intentosFallidos = intentosFallidos + 1

            UsuarioTextBox.Text = ""
            ClaveTextBox.Text = ""

            If intentosFallidos >= 3 Then
                MessageBox.Show("Has superado los 3 intentos permitidos. Login bloqueado.", "Error de Seguridad", MessageBoxButtons.OK, MessageBoxIcon.Stop)
                Btningre.Enabled = False
                UsuarioTextBox.Enabled = False
                ClaveTextBox.Enabled = False
            Else
                Dim intentosRestantes As Integer = 3 - intentosFallidos
                MessageBox.Show("Usuario o Clave incorrecto. Te quedan " & intentosRestantes & " intentos.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            End If
        End If
    End Sub
    Private Function GenerarHash(texto As String) As String
        Using sha256Hash As SHA256 = SHA256.Create()
            Dim bytes As Byte() = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(texto))
            Dim builder As New StringBuilder()
            For i As Integer = 0 To bytes.Length - 1
                builder.Append(bytes(i).ToString("x2"))
            Next
            Return builder.ToString()
        End Using
    End Function

    Private Sub UsuarioTextBox_TextChanged(sender As Object, e As EventArgs) Handles UsuarioTextBox.TextChanged

    End Sub

    Private Sub ClaveTextBox_TextChanged(sender As Object, e As EventArgs) Handles ClaveTextBox.TextChanged

    End Sub
End Class