﻿Module Module1
    Public permiso As String
    Public usuario As String

End Module
